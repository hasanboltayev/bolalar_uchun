import plotly.graph_objects as go

# Ma'lumotlar
guruhlar = ['Nazorat guruhi', 'Eksperimental guruhi']
ozlashtirish = [65, 85]  # Foizlarda

# Interaktiv diagramma
fig = go.Figure(data=[
    go.Bar(name='O‘zlashtirish darajasi', x=guruhlar, y=ozlashtirish, marker_color=['#636EFA', '#00CC96'])
])

# Grafik sozlamalari
fig.update_layout(
    title='Nazorat va Eksperimental guruhlardagi o‘zlashtirish darajasi',
    xaxis_title='Guruhlar',
    yaxis_title='O‘zlashtirish darajasi (%)',
    yaxis=dict(range=[0, 100]),
    template='plotly_white'
)

fig.show()