import tkinter as tk
from tkinter import PhotoImage
from PIL import Image, ImageTk
import random
import pyttsx3
from gtts import gTTS
from playsound import playsound
import os
import uuid

# Global o'zgaruvchilar
correct_count = 0
wrong_count = 0
selected_lang = "uz"

# Ovoz chiqarish funksiyasi
def speak_gtts_safe(text, lang_code):
    real_lang = lang_code
    if lang_code == "uz":
        real_lang = "ru"  # uz tilida gTTS yo‘q
    try:
        filename = f"voice_{uuid.uuid4()}.mp3"
        tts = gTTS(text=text, lang=real_lang)
        tts.save(filename)
        playsound(filename)
        os.remove(filename)
    except Exception as e:
        print(f"Ovoz chiqarishda xato: {e}")

# GUI oynani yaratish
root = tk.Tk()
root.state('zoomed')
root.title("Bolalar uchun interaktiv o‘rganish dasturi")
root.geometry("1366x768")
root.config(bg="#f0f8ff")

# Yuqori sarlavha
label1 = tk.Label(root, text="Bolalar uchun ingliz tilini interaktiv o‘rganish / बच्चों के लिए इंटरएक्टिव अंग्रेज़ी अध्ययन", font=("Arial", 20, "bold"), fg="darkblue", width=200, bg="#f0f8ff")
label1.pack(pady=20)

# Til tanlash tugmalari (yuqori o‘ng burchakda)
lang_switch_frame = tk.Frame(root, bg="#f0f8ff")
lang_switch_frame.place(relx=1.0, y=10, anchor="ne", x=-10)

def set_interface_language(lang_code):
    global selected_lang
    selected_lang = lang_code

    if lang_code == "ru":
        message_label.config(text="Выбранный язык: Русский")
        speak_gtts_safe("Выбран русский язык", "ru")
    elif lang_code == "en":
        message_label.config(text="Selected Language: English")
        speak_gtts_safe("English language selected", "en")
    elif lang_code == "hi":
        message_label.config(text="चयनित भाषा: हिंदी")
        speak_gtts_safe("हिंदी भाषा चुनी गई", "hi")

# Tugmalarni qo‘shish
tk.Button(lang_switch_frame, text="🇷🇺 Рус", font=("Arial", 10), command=lambda: set_interface_language("ru")).pack(side=tk.LEFT, padx=2)
tk.Button(lang_switch_frame, text="🇬🇧 Eng", font=("Arial", 10), command=lambda: set_interface_language("en")).pack(side=tk.LEFT, padx=2)
tk.Button(lang_switch_frame, text="🇮🇳 हिन्दी", font=("Arial", 10), command=lambda: set_interface_language("hi")).pack(side=tk.LEFT, padx=2)

# Til holatini aks ettiruvchi yorliq
message_label = tk.Label(root, text="", font=("Arial", 20, "italic"), fg="green", bg="#f0f8ff")
message_label.pack(pady=20)

# Dasturni ishga tushurish
root.mainloop()
