import tkinter as tk
from tkinter import StringVar, OptionMenu
from gtts import gTTS
from playsound import playsound
import uuid
import os

root = tk.Tk()
root.state('zoomed') 
root.title("Alifbo: Emoji bilan hayvonlar, mevalar, qushlar")
root.geometry("900x750")
root.config(bg="#f0f8ff")

language = StringVar(value="O‘zbek")  # Default til

alphabet = [chr(i) for i in range(65, 91)]  # A-Z



welcome_label = tk.Label(
    root,
    text="📘 Interaktiv Alifbo Dasturi\n\n"
         "Ushbu dastur bolalar uchun mo‘ljallangan bo‘lib,\n"
         "har bir harfga mos hayvon, meva va qush nomlari emoji orqali ko‘rsatiladi.\n"
         "Tilni (O‘zbek yoki Hindi) tanlab, harflarni bosish orqali o‘rganishni boshlang!\n\n"
         "🔊 Dastur tanlangan so‘zlarni ovozda o‘qib beradi.\n"
         "😊 O‘yin bilan birgalikda o‘rganing!",
    font=("Arial", 13, "italic"),
    bg="#f0f8ff",
    fg="#333333",
    justify="center"
)
welcome_label.grid(row=7, column=0, columnspan=13, pady=15)



welcome_label_hi = tk.Label(
    root,
    text="📘 इंटरएक्टिव वर्णमाला ऐप\n\n"
         "यह ऐप बच्चों के लिए बनाया गया है।\n"
         "हर अक्षर के लिए जानवर, फल और पक्षी के इमोजी दिखाए जाते हैं।\n"
         "भाषा चुनें (हिंदी या उज़्बेक) और अक्षर पर क्लिक करें!\n\n"
         "🔊 शब्दों को आवाज़ में सुनिए।\n"
         "😊 खेल के साथ मज़ेदार सीखने का अनुभव!",
    font=("Arial", 13, "italic"),
    bg="#f0f8ff",
    fg="#333333",
    justify="center"
)











# Til menyusi
OptionMenu(root, language, "O‘zbek", "Hindi").grid(row=0, column=0, columnspan=13, pady=10)

# Emoji lug‘atlar
animal_emojis = {
    "A": "🐜", "B": "🐻", "C": "🐱", "D": "🐶", "E": "🐘", "F": "🦊", "G": "🦒",
    "H": "🐹", "I": "🦔", "J": "🐆", "K": "🦘", "L": "🦁", "M": "🐵", "N": "🐮",
    "O": "🐂", "P": "🐼", "Q": "🦚", "R": "🐰", "S": "🐍", "T": "🐯", "U": "🦄",
    "V": "🦇", "W": "🐺", "X": "🦓", "Y": "🪱", "Z": "🦓"
}
fruit_emojis = {
    "A": "🍎", "B": "🍌", "C": "🍒", "D": "🍩", "E": "🥚", "F": "🍓", "G": "🍇",
    "H": "🍯", "I": "🍦", "J": "🥝", "K": "🥝", "L": "🍋", "M": "🥭", "N": "🥜",
    "O": "🍊", "P": "🍍", "Q": "🍰", "R": "🍚", "S": "🍉", "T": "🍅", "U": "🍇",
    "V": "🍆", "W": "🍉", "X": "🍈", "Y": "🍋", "Z": "🥒"
}
bird_emojis = {
    "A": "🕊️", "B": "🦅", "C": "🐦", "D": "🦆", "E": "🦉", "F": "🐥", "G": "🦤",
    "H": "🦜", "I": "🕊️", "J": "🐧", "K": "🦤", "L": "🦉", "M": "🦜", "N": "🐔",
    "O": "🐣", "P": "🦚", "Q": "🦃", "R": "🐓", "S": "🦅", "T": "🦆", "U": "🦉",
    "V": "🕊️", "W": "🐤", "X": "🦜", "Y": "🦅", "Z": "🦢"
}

# Nomlar lug‘ati (faqat o‘zbekcha va hindcha)
animals_uz = {"A": "Chigirtka", "B": "Ayiq", "C": "Mushuk", "D": "It", "E": "Fil"}
animals_hi = {"A": "चींटी", "B": "भालू", "C": "बिल्ली", "D": "कुत्ता", "E": "हाथी"}
fruits_uz = {"A": "Olma", "B": "Banan", "C": "Gilos", "D": "Shirinlik", "E": "Tuxum"}
fruits_hi = {"A": "सेब", "B": "केला", "C": "चेरी", "D": "डोनट", "E": "अंडा"}
birds_uz = {"A": "Tinchlik qushi", "B": "Burgut", "C": "Qush", "D": "O‘rdak", "E": "Boyo‘g‘li"}
birds_hi = {"A": "कबूतर", "B": "गिद्ध", "C": "पक्षी", "D": "बतख", "E": "उल्लू"}

# Emoji ko‘rsatish funksiyasi
def show_emojis(letter):
    lang = language.get()
    animal = animal_emojis.get(letter, "🐾")
    fruit = fruit_emojis.get(letter, "🍓")
    bird = bird_emojis.get(letter, "🐤")

    if lang == "O‘zbek":
        a_name = animals_uz.get(letter, "Hayvon")
        f_name = fruits_uz.get(letter, "Meva")
        b_name = birds_uz.get(letter, "Qush")
        speak_text = f"{a_name}, {f_name}, {b_name}"
        speak_lang = "ru"
    else:
        a_name = animals_hi.get(letter, "जानवर")
        f_name = fruits_hi.get(letter, "फल")
        b_name = birds_hi.get(letter, "पक्षी")
        speak_text = f"{a_name}, {f_name}, {b_name}"
        speak_lang = "hi"

    animal_label.config(text=f"{animal}\n{a_name}")
    fruit_label.config(text=f"{fruit}\n{f_name}")
    bird_label.config(text=f"{bird}\n{b_name}")
    speak(speak_text, speak_lang)

# Ovoz chiqarish
def speak(text, lang_code):
    try:
        filename = f"{uuid.uuid4()}.mp3"
        tts = gTTS(text=text, lang=lang_code)
        tts.save(filename)
        playsound(filename)
        os.remove(filename)
    except:
        print("Ovoz chiqarib bo‘lmadi")

# Alfavit tugmalari
def create_buttons():
    btn_style = {
        "font": ("Arial", 16, "bold"),
        "width": 4,
        "height": 2,
        "bg": "#b3e5fc",        # pastel ko‘k
        "activebackground": "#81d4fa",  # hover effekti
        "fg": "black",
        "relief": "groove",
        "borderwidth": 2,
        "cursor": "hand2"
    }

    for i, letter in enumerate(alphabet):
        btn = tk.Button(root, text=letter, command=lambda l=letter: show_emojis(l), **btn_style)
        row = 1 + i // 13
        col = i % 13
        btn.grid(row=row, column=col, padx=15, pady=15)


# Emoji label’lari
emoji_frame = tk.Frame(root, bg="#f0f8ff")
emoji_frame.grid(row=4, column=0, columnspan=13, pady=20)

animal_label = tk.Label(emoji_frame, text="", font=("Arial", 40), bg="#f0f8ff", justify="center")
animal_label.pack(side=tk.LEFT, padx=30)

fruit_label = tk.Label(emoji_frame, text="", font=("Arial", 40), bg="#f0f8ff", justify="center")
fruit_label.pack(side=tk.LEFT, padx=30)

bird_label = tk.Label(emoji_frame, text="", font=("Arial", 40), bg="#f0f8ff", justify="center")
bird_label.pack(side=tk.LEFT, padx=30)

# Ishga tushirish
create_buttons()
root.mainloop()
