import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from gtts import gTTS
import os
import uuid
from playsound import playsound

# Ovoz funksiyasi (gTTS bilan)
def speak(text, lang):
    try:
        filename = f"temp_{uuid.uuid4()}.mp3"
        tts = gTTS(text=text, lang=lang)
        tts.save(filename)
        playsound(filename)
        os.remove(filename)
    except Exception as e:
        print(f"Ovoz chiqarishda xato: {e}")

# Oyna sozlamalari
root = tk.Tk()
root.state('zoomed')
root.title("Интерактивное изучение хинди, русского и английского языков для детей/बच्चों के लिए इंटरएक्टिव हिंदी, रूसी और अंग्रेज़ी सीखना")
root.geometry("1366x768")
root.configure(bg="#e6f2ff")

# Rasm ko‘rsatish uchun Label
image_label = tk.Label(root, bg="#e6f2ff")
image_label.pack(pady=20)

# So‘z va rasmni ko‘rsatish funksiyasi
def show_word(word):
    # O‘zbekcha va hindcha qismlarni ajratib olish
    try:
        uzbek_part, hindi_part = word.split(" / ")
    except:
        uzbek_part = word
        hindi_part = ""

    # Avval o‘zbekcha o‘qilsin (ru orqali), so‘ng hindcha (hi orqali)
    speak(uzbek_part, lang='ru')
    if hindi_part:
        hindi_clean = hindi_part.split(" (")[0].strip()
        speak(hindi_clean, lang='hi')

    # Rasm ko‘rsatish
    image_file_name = uzbek_part.lower().replace("‘", "").replace("’", "").replace(" ", "_") + ".jpg"
    image_path = os.path.join("images", image_file_name)
    if os.path.exists(image_path):
        img = Image.open(image_path)
        img = img.resize((200, 200))
        photo = ImageTk.PhotoImage(img)
        image_label.config(image=photo, text="")
        image_label.image = photo
    else:
        image_label.config(image='', text=f"{uzbek_part} (rasm topilmadi)")

# So‘zlar ro‘yxati
words = [
    "Olma / सेब (seb)! Яблоко! Apple!",
    "Sharcha / गेंद (gend)! Мячик! Ball! ",
    "Mushuk / बिल्ली (billi)! Кошка! Cat!",
    "It / कुत्ता (kutta)! Собака! Dog! ",
    "Fil / हाथी (haathi)! Слон! Elephant!",
    "Baliq / मछली (machhli)! Рыба! Fish! ",
    "Jirafa / जिराफ़ (jiraaf)! Жираф! Giraffe!",
    "Uy / घर (ghar)! Дом! House! ",
    "Muz / बर्फ (barf)! Лёд! Ice! ",
    "Sharbat / रस (ras)! Сок! Juice!",
    "Qog‘oz qush / पतंग (patang)! Бумажный змей! Kite!",
    "Sher / शेर (sher)! Лев! Lion! ",
    "Maymun / बंदर (bandar)! Обезьяна! Monkey! ",
    "Uyacha / घोंसला (ghonsla)! Гнездо! Nest!",
    "Apelsin / संतरा (santra)! Апельсин! Orange! ",
    "Ruchka / पेन (pen)! Ручка! Pen! ",
    "Malika / रानी (rani)! Королева! Queen!",
    "Quyon / खरगोश (khargosh)! Кролик! Rabbit! ",
    "Quyosh / सूरज (sooraj)! Солнце! Sun! ",
    "Daraxt / पेड़ (ped)! Дерево! Tree! ",
    "Soyabon / छाता (chaata)! Зонт! Umbrella! ",
    "Furgon / वैन (van)! Фургон! Van! ",
    "Soat / घड़ी (ghadi)! Часы! Clock!",
    "Ksilofon / ज़ाइलोफोन (xylophone)! Ксилофон! Xylophone!",
    "Qatiq / दही (dahi)! Йогурт! Yogurt! ",
    "Zebra / ज़ेब्रा (zebra)! Зебра! Zebra!"
]

# Tugmalar paneli
button_frame = tk.Frame(root, bg="#e6f2ff")
button_frame.pack()

# Har bir tugma uchun chiroyli joylashuv
for i, word in enumerate(words):
    btn = tk.Button(button_frame, text=word, width=22, height=2,
                    bg="#add8e6", fg="black", font=("Arial", 11, "bold"),
                    command=lambda w=word: show_word(w))
    btn.grid(row=i//4, column=i%4, padx=6, pady=6)

# Dastur oynasini boshlash
root.mainloop()
