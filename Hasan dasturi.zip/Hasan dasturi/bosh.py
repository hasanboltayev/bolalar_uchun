from tkinter import * 
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess
import sys

class Developer:
    def __init__(self, root):
        self.root = root
        root.state('zoomed') 
        self.root.geometry("1530x790+0+0")
        self.root.title(" Обучение узбекскому, хинди, русскому и английскому языкам детей дошкольного возраста")

        img_top = Image.open("img.png")
        img_top = img_top.resize((700, 500), Image.Resampling.LANCZOS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=0, width=1520, height=620)

        main_frame = Frame(root, bd=2, bg="skyblue")
        main_frame.place(x=0, y=620, width=1520, height=100)

        lbl = Label(main_frame, font=("times new roman", 13, "bold"),
                    text="Обучение узбекскому, хинди, русскому и английскому языкам детей дошкольного возраста \n  प्रीस्कूल बच्चों को उज़्बेक, हिंदी, रूसी और अंग्रेज़ी भाषाएँ सिखाना", fg="red", bg="skyblue")
        lbl.place(x=0, y=10, width=500, height=60)

        btn1 = Button(main_frame, font=("times new roman", 10, "italic"), text="Interaktiv darslar/Интерактивные уроки/Interactive lessons/ इंटरएक्टिव पाठ(Interaktiv paath)",
                      bg="green", command=self.open_alphabet)
        btn1.place(x=500, y=10, width=300, height=50)  

        btn2 = Button(main_frame, font=("times new roman", 12, "italic"), text="Alifbo / वर्णमाला",
                      bg="blue", command=self.open_interactive_lessons)
        btn2.place(x=820, y=10, width=250, height=50)

        btn3 = Button(main_frame, font=("times new roman", 12, "italic"), text="Mevalar / फल",
                      bg="yellow", command=self.open_meva)
        btn3.place(x=1100, y=10, width=210, height=50)        

    # FUNKSIYALAR tashqarida yoziladi
    def open_alphabet(self):
        self.root.destroy()  # Hozirgi oynani yopadi
        subprocess.Popen([sys.executable, "index.py"])  # index.py faylini ishga tushuradi

    def open_interactive_lessons(self):
        self.root.destroy()
        subprocess.Popen([sys.executable, "index1.py"])  # index1.py faylini ishga tushuradi
    
    def open_meva(self):
        self.root.destroy()
        subprocess.Popen([sys.executable, "index2.py"])  # index2.py faylini ishga tushuradi
        
if __name__ == "__main__":
    root = Tk()
    obj = Developer(root)
    root.mainloop()
