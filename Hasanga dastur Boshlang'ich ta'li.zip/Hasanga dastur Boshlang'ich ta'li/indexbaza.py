# Interaktiv til o'rgatish dasturi (Tkinter + MySQL)

import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random
import pyttsx3
from gtts import gTTS
from playsound import playsound
import os
import uuid
import mysql.connector
from mysql.connector import Error

# === GLOBAL O'ZGARUVCHILAR ===
conn = None
cursor = None
user_name = ""
user_surname = ""
correct_count = 0
wrong_count = 0
selected_lang = "uz"
current_category = None
current_answer = None

# === MYSQL BILAN ULANISH ===
def connect_to_database():
    global conn, cursor
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="your_password",  # <-- o'z parolingizni kiriting
            database="til_dasturi"
        )
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                surname VARCHAR(100),
                category VARCHAR(255),
                question TEXT,
                user_answer TEXT,
                correct_answer TEXT,
                is_correct BOOLEAN,
                language VARCHAR(10),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
    except Error as e:
        print(f"MySQL ulanishda xato: {e}")

# === FOYDALANUVCHI ISMI-FAMILYASI OYNASI ===
def ask_user_info(root):
    info_window = tk.Toplevel(root)
    info_window.title("Foydalanuvchi ma'lumotlari")
    info_window.geometry("400x200")
    info_window.grab_set()

    tk.Label(info_window, text="Ismingiz:", font=("Arial", 12)).pack(pady=5)
    name_entry = tk.Entry(info_window, font=("Arial", 12))
    name_entry.pack(pady=5)

    tk.Label(info_window, text="Familyangiz:", font=("Arial", 12)).pack(pady=5)
    surname_entry = tk.Entry(info_window, font=("Arial", 12))
    surname_entry.pack(pady=5)

    def save_info_and_continue():
        global user_name, user_surname
        user_name = name_entry.get().strip()
        user_surname = surname_entry.get().strip()
        if user_name and user_surname:
            info_window.destroy()
        else:
            messagebox.showwarning("Ogohlantirish", "Iltimos, ism va familya kiriting!")

    tk.Button(info_window, text="Boshlash", font=("Arial", 12), bg="green", fg="white",
              command=save_info_and_continue).pack(pady=20)

# === NATIJANI BAZAGA SAQLASH ===
def save_result(category, question, user_answer, correct_answer, is_correct, lang):
    if conn:
        try:
            cursor.execute("""
                INSERT INTO results (name, surname, category, question, user_answer, correct_answer, is_correct, language)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                user_name,
                user_surname,
                category,
                question,
                user_answer,
                correct_answer,
                is_correct,
                lang
            ))
            conn.commit()
        except Error as e:
            print(f"Ma'lumotni yozishda xato: {e}")

# === GAPIRISH FUNKSIYASI ===
def speak_gtts(text, lang='uz'):
    try:
        if lang == 'uz':
            lang = 'ru'  # gTTS "uz"ni qo'llamaydi
        filename = f"voice_{uuid.uuid4()}.mp3"
        tts = gTTS(text=text, lang=lang)
        tts.save(filename)
        playsound(filename)
        os.remove(filename)
    except Exception as e:
        print(f"Ovoz chiqarishda xato: {e}")

# === JAVOBNI TEKSHIRISH ===
def check_answer(user_answer):
    global current_answer, correct_count, wrong_count
    is_correct = 1 if user_answer.lower().strip() == current_answer.lower().strip() else 0

    if is_correct:
        correct_count += 1
        speak_gtts("To'g'ri javob!", lang=selected_lang)
    else:
        wrong_count += 1
        speak_gtts("Xato javob!", lang=selected_lang)

    save_result(current_category, "Bu nima?", user_answer, current_answer, is_correct, selected_lang)
    root.after(1500, lambda: show_word_and_image(current_category))

# === KATEGORIYADAN TASODIFIY SO'Z VA RASM ===
def show_word_and_image(category):
    global current_category, current_answer
    current_category = category
    word_image = random.choice(example_items)  # Test uchun bir xil rasm
    current_answer = word_image[0]
    image_label.config(image=word_image[1])
    word_label.config(text="Bu nima?")
    create_answer_buttons()

# === TUGMALAR YARATISH ===
def create_answer_buttons():
    for widget in frame_buttons.winfo_children():
        widget.destroy()
    options = [item[0] for item in random.sample(example_items, 4)]
    if current_answer not in options:
        options[0] = current_answer
    random.shuffle(options)
    for option in options:
        tk.Button(frame_buttons, text=option, command=lambda ans=option: check_answer(ans), width=20).pack(pady=5)

# === RASM VA ELEMENTLAR (Test uchun bitta rasm) ===
example_image = ImageTk.PhotoImage(Image.new('RGB', (200, 100), color='blue'))
example_items = [
    ("Mushuk", example_image),
    ("It", example_image),
    ("Fil", example_image),
    ("Quyon", example_image),
    ("Tovuq", example_image),
    ("Sigir", example_image),
    ("Qo'y", example_image)
]

# === GUI YARATISH ===
root = tk.Tk()
root.title("Til o'rgatish dasturi")
root.geometry("600x500")

connect_to_database()
ask_user_info(root)

tk.Label(root, text="Interaktiv o‘yin - so‘zni tanlang", font=("Arial", 16)).pack(pady=10)
word_label = tk.Label(root, text="", font=("Arial", 24))
word_label.pack(pady=10)
image_label = tk.Label(root)
image_label.pack(pady=10)
frame_buttons = tk.Frame(root)
frame_buttons.pack(pady=10)

show_word_and_image("Hayvonlar")

root.mainloop()

# Dastur tugaganda ulanishni yopish
if conn:
    cursor.close()
    conn.close()
