import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import os
import sys

# 🔐 Kirishni tekshirish funksiyasi
def login_check():
    username = username_entry.get()
    password = password_entry.get()
    if username == "admin" and password == "1234":
        messagebox.showinfo("Kirish", "Muvaffaqiyatli kirildi!")
        try:
            subprocess.Popen([sys.executable, "bosh.py"])  # boshqa fayl ochiladi
        except Exception as e:
            messagebox.showerror("Xatolik", f"Dastur ochilmadi: {e}")
        root.after(500, root.destroy)
    else:
        messagebox.showerror("Xatolik", "Login yoki parol noto‘g‘ri!")

# 🖥 Asosiy oyna
root = tk.Tk()
root.title("Zamonaviy Login Oynasi")
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}")
root.attributes("-fullscreen", True)

# 🎨 Canvas fon
canvas = tk.Canvas(root, width=screen_width, height=screen_height)
canvas.pack(fill="both", expand=True)

# 🖼 Fon rasmi bor-yo‘qligini tekshirish
bg_path = "fon2.png"
if os.path.exists(bg_path):
    try:
        bg_image = Image.open(bg_path)
        bg_image = bg_image.resize((screen_width, screen_height), Image.LANCZOS)
        bg_photo = ImageTk.PhotoImage(bg_image)
        canvas.create_image(0, 0, image=bg_photo, anchor="nw")
    except:
        canvas.create_rectangle(0, 0, screen_width, screen_height, fill="#DDEEFF", outline="")
else:
    canvas.create_rectangle(0, 0, screen_width, screen_height, fill="#DDEEFF", outline="")

# 📍 Markaz koordinatalar
center_x = screen_width // 2
center_y = screen_height // 2
label_offset_x = -150
entry_offset_x = 50

# 🧾 Login
login_label = tk.Label(root, text="Login:", font=("Helvetica", 16), bg="white")
canvas.create_window(center_x + label_offset_x, center_y - 60, window=login_label)

username_entry = tk.Entry(root, font=("Helvetica", 16), width=25, bd=2, relief="groove")
canvas.create_window(center_x + entry_offset_x, center_y - 60, window=username_entry)

# 🔐 Parol
password_label = tk.Label(root, text="Parol:", font=("Helvetica", 16), bg="white")
canvas.create_window(center_x + label_offset_x, center_y, window=password_label)

password_entry = tk.Entry(root, show="*", font=("Helvetica", 16), width=25, bd=2, relief="groove")
canvas.create_window(center_x + entry_offset_x, center_y, window=password_entry)

# 🚪 Kirish tugmasi
login_button = tk.Button(
    root,
    text="Kirish",
    font=("Helvetica", 14, "bold"),
    bg="#007ACC",
    fg="white",
    width=15,
    height=1,
    relief="flat",
    command=login_check
)
canvas.create_window(center_x, center_y + 70, window=login_button)

# ⎋ ESC tugmasi bilan chiqish
root.bind("<Escape>", lambda e: root.destroy())

# 🔁 Boshlash
root.mainloop()
